// server.js
const express = require('express');
const rateLimit = require('express-rate-limit');
const admin = require('firebase-admin');
const morgan = require('morgan');
const path = require('path');
const app = express();

// Firebase Admin SDK initialization
const serviceAccount = require('./serviceAccountKey.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://ddos-bmu-default-rtdb.firebaseio.com'
});

const db = admin.database();
const ref = db.ref('/ddos-attacks');

// Ensure the DDoS data is initialized in the database
ref.once('value', (snapshot) => {
  if (snapshot.val() === null) {
    ref.set({
      total: 0,
      ongoing: 0,
      recovered: 0
    });
  }
});

// Define rate limiter middleware
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // max 100 requests per 15 minutes
  handler: (req, res) => {
    // Increment attack counts in Firebase
    ref.child('total').transaction((currentValue) => (currentValue || 0) + 1);
    ref.child('ongoing').transaction((currentValue) => (currentValue || 0) + 1);

    res.status(429).send('Too many requests - your IP is being rate limited.');
  }
});

// Use Morgan for logging HTTP requests
app.use(morgan('dev'));

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Use rate limiter middleware
app.use(limiter);

// Route to recover an attack
app.post('/recover', (req, res) => {
  ref.child('ongoing').transaction((currentValue) => Math.max((currentValue || 0) - 1, 0));
  ref.child('recovered').transaction((currentValue) => (currentValue || 0) + 1);
  res.send('Recovered an attack');
});

// Start the server
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running at http://127.0.0.1:${port}/`);
});

