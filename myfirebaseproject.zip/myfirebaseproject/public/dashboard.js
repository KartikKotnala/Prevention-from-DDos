// dashboard.js

// Firebase v9 modular SDK
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-app.js";
import { getDatabase, ref, onValue } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-database.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCG9O6XYp5GSa5rwRUEkPoyhL_raKMeAjQ",
  authDomain: "ddos-bmu.firebaseapp.com",
  databaseURL: "https://ddos-bmu-default-rtdb.firebaseio.com",
  projectId: "ddos-bmu",
  storageBucket: "ddos-bmu.appspot.com",
  messagingSenderId: "479569478694",
  appId: "1:479569478694:web:4a9bcd9bbc2dfde55912e7"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);
const ddosRef = ref(database, 'ddos-attacks');

onValue(ddosRef, (snapshot) => {
    const data = snapshot.val();
    console.log('Data received:', data); // Add this to inspect the data
    document.getElementById('total-attacks').textContent = data.total || 0;
    document.getElementById('ongoing-attacks').textContent = data.ongoing || 0;
    document.getElementById('recovered-attacks').textContent = data.recovered || 0;
});


